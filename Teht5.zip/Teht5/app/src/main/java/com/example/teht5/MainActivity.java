package com.example.teht5;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TopFragment.buttonListener, BottomFragment.buttonListener  {
    private TopFragment tF;
    private BottomFragment bF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tF = new TopFragment();
        bF = new BottomFragment();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.topContainer, tF)
                .replace(R.id.botContainer, bF)
                .commit();

    }

    @Override
    public void botFragSwitch(CharSequence input) {
        tF.updateBotText(input);
    }

    @Override
    public void topFragSwitch(CharSequence input) {
        bF.updateTopText(input);
    }
}

package com.example.teht5;

        import android.content.Context;
        import android.net.Uri;
        import android.os.Bundle;

        import androidx.fragment.app.Fragment;
        import androidx.fragment.app.FragmentTransaction;

        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;

public class BottomFragment extends Fragment {

    private Button button;
    private TextView textView;
    private EditText editText;
    private buttonListener mListener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_bottom, container, false);

        button = v.findViewById(R.id.botB);
        textView = v.findViewById(R.id.botTv);
        editText = v.findViewById(R.id.topEt);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence input = editText.getText();
                mListener.botFragSwitch(input);
            }
        });

        return v;
    }

    public void updateTopText(CharSequence newText)
    {
        editText.setText(newText);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof buttonListener ){
            mListener = (buttonListener) context;
        }
        else
        {
            throw new RuntimeException(context.toString() + " needs button listener");
        }
    }

    @Override
    public void onDetach(){
        super.onDetach();
        mListener = null;
    }

    public interface buttonListener{
        void botFragSwitch(CharSequence input);
    }
}

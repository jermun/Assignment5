package com.example.assignment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Button bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final ConnectivityManager cm = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt = (Button) findViewById(R.id.btn);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                if(null != activeNetwork){
                    if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI){
                        Toast.makeText(getApplicationContext(), "You are connected", Toast.LENGTH_LONG).show();
                    }
                    if(activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE){
                        Toast.makeText(getApplicationContext(), "You are connected", Toast.LENGTH_LONG).show();
                    }
                }
                else
                    Toast.makeText(getApplicationContext(), "No internet connection", Toast.LENGTH_LONG).show();
            }
        });
        {

        }
    }
}
